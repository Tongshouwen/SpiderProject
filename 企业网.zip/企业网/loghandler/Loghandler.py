# -*- coding:utf-8 -*-
# _author = TongShouWen
import logging
import os


class LogHandler(object):
    def __init__(self):
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s  %(filename)s : %(levelname)s  %(message)s',
            datefmt='%Y-%m-%d %A %H:%M:%S',
            filename=os.path.join('./', 'log.txt'),
            filemode='a+'
        )
        console = logging.StreamHandler()
        console.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s  %(filename)s : %(levelname)s  %(message)s')
        console.setFormatter(formatter)
        logging.getLogger().addHandler(console)

    def log_info(self, info):
        logging.info(info)

    def log_warning(self):
        logging.warning('this is log about warning')

    def log_error(self, error):
        logging.error(error)

    def log_critical(self):
        logging.error('this is log about critical')
