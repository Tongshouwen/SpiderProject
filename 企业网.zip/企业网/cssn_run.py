# -*- coding:utf-8 -*-
# _author = TongShouWen
import gevent
from gevent import monkey
import multiprocessing
from multiprocessing import Queue, Process
import csv
import requests
import base64
import string
import math
from 企业网.loghandler.Loghandler import LogHandler
import sys
from requests.exceptions import ConnectTimeout, ConnectionError
import time


monkey.patch_all(thread=False)


class SpiderMain(Process):
    def __init__(self, q):
        Process.__init__(self)
        self.q = q

    def start_run(self):
        for s in string.ascii_uppercase:
            if s == 'O' or s == 'I':
                continue
            else:
                self.q.put(s)
        print(self.q.qsize())

    def downloader(self, key_word, log, page=1, num=0):
        if num == 5:
            return 'False'
        headers = {
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Connection": "keep-alive",
            "Content-Length": "117",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Cookie": "JSESSIONID=464ADD8BBB072F1D88B48015BB41CD90; __FTabceffgh=2018-4-26-9-6-6; __NRUabceffgh=1524704766456; __RTabceffgh=2018-4-26-9-6-6; __root_domain_v=.cssn.net.cn; _qddaz=QD.vtrta.adq5i4.jgftuojc; _qdda=4-1.1; _qddab=4-3grsbv.jgg57n68; _qddamta_2852130103=4-500372078",
            "Host": "www.cssn.net.cn",
            "Origin": "http://www.cssn.net.cn",
            "Referer": "http://www.cssn.net.cn/cssn/cssn/search/search_result.jsp",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36",
            "X-Requested-With": "XMLHttpRequest",
        }
        data = {
            "pageNo": base64.b64encode(str(page).encode('utf8')),
            "pageSize": "OQ==",
            "search_info13": base64.b64encode(key_word.encode('utf8')),
            "classify_search_code": "Mw==",
            "search_or_sort_status": "Mw==",
        }
        url = 'http://www.cssn.net.cn/cssn/frame/product_Search/getListClassify'
        try:
            response = requests.post(url=url, data=data, headers=headers, timeout=60)
            if response.status_code == 200:
                return response
            else:
                num += 1
                log.log_info('StatusCodeError,正在尝试第{0}次重新请求...'.format(num))
                response = self.downloader(key_word, log, page, num)
                log.log_info('尝试第{0}次请求时，成功'.format(num))
                return response
        except:
            num += 1
            log.log_info('ConnectionError, 正在尝试第{0}次重新请求...   key_word：'.format(num) + key_word + '   page：' + str(page))
            response = self.downloader(key_word, log, page, num)
            log.log_info('尝试第{0}次请求时，成功   key_word：'.format(num) + key_word + '   page：' + str(page))
            return response

    def detail_downloader(self, row, num=0):
        if num == 5:
            return 'False'
        headers = {
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Connection": "keep-alive",
            "Content-Length": "59",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Cookie": "JSESSIONID=464ADD8BBB072F1D88B48015BB41CD90; __FTabceffgh=2018-4-26-9-6-6; __NRUabceffgh=1524704766456; __RTabceffgh=2018-4-26-9-6-6; __root_domain_v=.cssn.net.cn; _qddaz=QD.vtrta.adq5i4.jgftuojc; _qddab=4-3grsbv.jgg57n68",
            "Host": "www.cssn.net.cn",
            "Origin": "http://www.cssn.net.cn",
            "Referer": "http://www.cssn.net.cn/cssn/cssn/MandStandard/gyDetail.jsp?bz_code=NDI1MjY3&db_info=VF9OX1RSU19TVEFOREFSRF9XRUI=&A100=R0IvVCAxMDI4LTIwMDA=&A101=MjAwMC0wMS0wNQ==&price=MTQ=",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36",
            "X-Requested-With": "XMLHttpRequest",
        }
        data = {
            "search_info": base64.b64encode(row[0].encode('utf8')),
            "db_info": "VF9OX1RSU19TVEFOREFSRF9XRUI=",
        }
        url = 'http://www.cssn.net.cn/cssn/frame/product_Search/getDetailInfo'
        try:
            response = requests.post(url=url, data=data, headers=headers, timeout=60)
            if response.status_code == 200:
                return response
            else:
                num += 1
                return self.detail_downloader(row, num)
        except ConnectTimeout:
            num += 1
            # row[2].log_info('ConnectTimeout for detail_downloader, 正在尝试第{0}次   search_info：{1}'.format(num, row[0]))
            response = self.detail_downloader(row, num)
            # row[2].log_info('ConnectTimeout for detail_downloader, 尝试第{0}次成功   search_info：{1}'.format(num, row[0]))
            return response
        except:
            num += 1
            # row[2].log_info('ConnectionError for detail_downloader, 正在尝试第{0}次   search_info：{1}'.format(num, row[0]))
            response = self.detail_downloader(row, num)
            # row[2].log_info('ConnectionError for detail_downloader, 尝试第{0}次成功   search_info：{1}'.format(num, row[0]))
            return response

    def footer_downloader(self, row, num=0):
        if num == 5:
            return 'False'
        headers = {
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Connection": "keep-alive",
            "Content-Length": "59",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Cookie": "JSESSIONID=464ADD8BBB072F1D88B48015BB41CD90; __FTabceffgh=2018-4-26-9-6-6; __NRUabceffgh=1524704766456; __RTabceffgh=2018-4-26-9-6-6; __root_domain_v=.cssn.net.cn; _qddaz=QD.vtrta.adq5i4.jgftuojc; _qddab=4-3grsbv.jgg57n68",
            "Host": "www.cssn.net.cn",
            "Origin": "http://www.cssn.net.cn",
            "Referer": "http://www.cssn.net.cn/cssn/cssn/MandStandard/gyDetail.jsp?bz_code=NDI1MjY3&db_info=VF9OX1RSU19TVEFOREFSRF9XRUI=&A100=R0IvVCAxMDI4LTIwMDA=&A101=MjAwMC0wMS0wNQ==&price=MTQ=",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36",
            "X-Requested-With": "XMLHttpRequest",
        }
        data = {
            "search_info": base64.b64encode(row[0].encode('utf8')),
            "db_info": "VF9OX1RSU19TVEFOREFSRF9XRUI=",
        }
        url = 'http://www.cssn.net.cn/cssn/frame/product_Search/getDetailFootInfo'
        try:
            response = requests.post(url=url, data=data, headers=headers, timeout=60)
            if response.status_code == 200:
                return response
            else:
                num += 1
                return self.footer_downloader(row, num)
        except ConnectTimeout:
            num += 1
            # row[2].log_info('ConnectTimeout for footer_downloader, 正在尝试第{0}次   search_info：{1}'.format(num, row[0]))
            response = self.footer_downloader(row, num)
            # row[2].log_info('ConnectTimeout for footer_downloader, 尝试第{0}次成功   search_info：{1}'.format(num, row[0]))
            return response
        except:
            num += 1
            # row[2].log_info('ConnectionError for footer_downloader, 正在尝试第{0}次   search_info：{1}'.format(num, row[0]))
            response = self.footer_downloader(row, num)
            # row[2].log_info('ConnectionError for footer_downloader, 尝试第{0}次成功   search_info：{1}'.format(num, row[0]))
            return response

    def parser(self, res):
        try:
            html = res.json()
            rows_list = html['rows']
            return rows_list
        except Exception as e:
            print('错误', res, e)

    def detail_parser(self, res):
        detail = res.json()['list'][0]
        new_dict = dict()
        # 中文名称
        new_dict['chiness_name'] = detail['a298']
        # 英文名称
        new_dict['english_name'] = detail['a302']
        # 简称
        new_dict['abbreviation'] = detail['a100']
        # 发布日期
        new_dict['release_date'] = detail['a101']
        # 实施日期
        new_dict['material_date'] = detail['a205']
        # ---制定机构---
        new_dict['mechanism'] = detail['a209']
        # 全文语种
        new_dict['languages'] = detail['a300']
        # 全文页数
        new_dict['page'] = detail['a305']
        # 标准来源
        new_dict['source'] = detail['source']
        # 发布单位
        new_dict['release_unit'] = detail['a104'] + detail['b102']
        # 适用范围
        new_dict['scope_of_application'] = detail['a330'].strip().replace('\n', '')
        # print(new_dict)
        return new_dict

    def pub_detail_parser(self, detail_list):
        for detail in detail_list:
            new_dict = dict()
            # 中文名称
            new_dict['chiness_name'] = detail['a298']
            # 英文名称
            new_dict['english_name'] = detail['a302']
            # 简称
            new_dict['abbreviation'] = detail['a100']
            yield new_dict

    def footer_parser(self, res, detail_dict):
        detail_dict['replace_old'] = list()
        detail_dict['replace_new'] = list()
        detail_dict['quote'] = list()
        html = res.json()
        # 代替了如下标准
        list_1_list = html['list1']
        detail_list_1 = self.pub_detail_parser(list_1_list)
        for detail in detail_list_1:
            detail_dict['replace_old'].append(detail)
        # 被如下标准代替
        list_2_list = html['list2']
        detail_list_2 = self.pub_detail_parser(list_2_list)
        for detail in detail_list_2:
            detail_dict['replace_new'].append(detail)
        # 引用了如下标准
        list_3_list = html['list3']
        detail_list_3 = self.pub_detail_parser(list_3_list)
        for detail in detail_list_3:
            detail_dict['quote'].append(detail)
        # 采用关系
        detail_dict['usedRelation'] = html['usedRelation']
        return detail_dict

    def get_max_page(self, res):
        total = res.json()['total']
        max_page = math.ceil(int(total) / 12) + 1
        # print(max_page)
        return max_page

    def outputer(self, data, w):
        # print(data)
        w.writerow(data)

    def second_start(self, row):
        response = self.detail_downloader(row)
        if response == "False":
            row[2].log_error('Unsuccessful request for detail, 请求5次后未成功!!   search_info：' + row[0])
        else:
            detail_dict = self.detail_parser(response)
            res1 = self.footer_downloader(row)
            if res1 == "False":
                row[2].log_error('Unsuccessful request for footer, 请求5次后未成功!!   search_info：' + row[0])
            else:
                data = self.footer_parser(res1, detail_dict)
                self.outputer(data, row[1])

    def pub_start(self, res, w, log):
        row_list = self.parser(res)
        # print('==========================================', len(row_list))
        task = []
        for row in row_list:
            # self.second_start(row['a001'])
            task.append(gevent.spawn(self.second_start, [row['a001'], w, log]))
        gevent.joinall(task)

    def run(self):
        log = LogHandler()
        key_word = None
        while True:
            if self.q.empty():
                break
            key_word = self.q.get()
            # if key_word == 'B':
            file = open(key_word + '.csv', 'a+', encoding='gb18030', newline='')
            writer = csv.DictWriter(file,
                                    fieldnames=['chiness_name', 'english_name', 'abbreviation', 'release_date',
                                                'material_date', 'mechanism', 'languages', 'page', 'source',
                                                'release_unit', 'scope_of_application', 'replace_old',
                                                'replace_new', 'quote', 'usedRelation'])
            writer.writeheader()
            res = self.downloader(key_word, log)
            if res == 'False':
                log.log_error('Unsuccessful request, 请求5次后未成功!!   keyword：' + key_word + '   page：' + '1')
                continue
            else:
                # print(res)
                self.pub_start(res, writer, log)
            # --=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
            max_page = self.get_max_page(res)
            for page in range(2, int(max_page)):
                # print(page, key_word)
                res = self.downloader(key_word, log, page)
                if res == 'False':
                    log.log_error('Unsuccessful request, 请求5次后未成功!!   keyword：' + key_word + '   page：' + str(page))
                    continue
                else:
                    # print('''***************************''', res)
                    self.pub_start(res, writer, log)
                sys.stdout.write('\r')
                sys.stdout.write("{0}：{1}% ({2}/{3}) |{4}".format(key_word, math.ceil((page / int(max_page)) * 100),
                                                                  page, max_page,
                                                                  int(math.ceil((page / int(max_page)) * 100)) * '>'))
                sys.stdout.flush()
                time.sleep(0.001)
            sys.stdout.write('|')
            sys.stdout.write('\n')
        print(key_word, '————————————————down')


if __name__ == '__main__':
    q = Queue()
    spider = SpiderMain(q)
    spider.start_run()
    for n in range(8):
        p = multiprocessing.Process(target=spider.run)
        p.start()
